﻿using YVendingMachine;

class Program
{
    static void Main(string[] args)
    {

        var automat = InitYVendingMachine();
        Wallet wallet = InitWallet();
        Console.WriteLine(wallet.AmountAvailable);
        automat.Start(wallet);
    }

    static VendingMachine InitYVendingMachine()
    {


        var automat = new VendingMachine();
        
        automat.Products.AddRange(new Product[]
        {

            new HotDrink("Coffee", 10, "For aldults!"),
            new HotDrink("Hot Te", 20, "Good for cold Weather."),
            new HotDrink("Hot Chocolate Drink", 30, "Sweet Warm Drink!"),

            new WarmFood("Jollof Rice", 60, "Yummy and tasty"),         
            new WarmFood("Vegetables", 80, "For the diets"),
            new WarmFood("Fufu Food", 100, "For the Big Boys"),

            new IceCream("Vanilla Ice Cream", 15, "Sweet cold cream"),
            new IceCream("Strawberry Ice Cream", 25, "Frosy cold"),
            new IceCream("Mint Chocolate Ice Cream", 35, "Icee cold Choco"),
        });
        
        return automat;
    }

    static Wallet InitWallet()
    {
        var w = new Wallet();
        w.PutIn(1, 10);
        w.PutIn(5, 10);
        w.PutIn(10, 10);
        return w;
    }


}