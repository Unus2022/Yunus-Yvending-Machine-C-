namespace YVendingMachine;

public class HotDrink : Product
{
    public HotDrink(string name, int price, string description) 
        : base(name, price, description)
    {
    }

    public override void Use()
    {
        Console.WriteLine($"Here you go with your hot {Name}");
    }
}