namespace YVendingMachine;

public interface IProduct
{
    string Description();
    void Buy();
    void Use();
}