﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YVendingMachine
{
    public class IceCream : Product
    {
        public IceCream(string name, int price, string description)
            : base(name, price, description)
        {
        }

        public override void Use()
        {
            Console.WriteLine($"Enjoy your cold {Name} made with Passion");
        }
    }

}

