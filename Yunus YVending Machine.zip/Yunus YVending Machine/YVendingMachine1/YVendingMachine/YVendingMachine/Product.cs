namespace YVendingMachine;

public abstract class Product : IProduct
{
    private string _description;
    
    public string Name { get; }
    public int Price { get; }

    public Product(string name, int price, string description)
    {
        Name = name;
        Price = price;
        _description = description;
    }
    
    public virtual string Description()
    {
        return _description;
    }

    public virtual void Buy()
    {
        Console.WriteLine($"I want to buy {Name}");
    }

    public abstract void Use();
}