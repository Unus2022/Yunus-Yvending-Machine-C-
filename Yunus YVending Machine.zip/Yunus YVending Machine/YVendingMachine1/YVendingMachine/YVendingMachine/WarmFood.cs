namespace YVendingMachine;

public class WarmFood : Product
{
    public WarmFood(string name, int price, string description)
        : base(name, price, description)
    {
    }

    public override void Use()
    {
        Console.WriteLine($"Enjoy your warm tasty {Name}");
    }
}